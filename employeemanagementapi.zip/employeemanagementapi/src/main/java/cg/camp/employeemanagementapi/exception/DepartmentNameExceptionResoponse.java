
package cg.camp.employeemanagementapi.exception;

public class DepartmentNameExceptionResoponse {
	
	private String  deptName;
	

	public DepartmentNameExceptionResoponse(String deptName) {
		super();
		this.deptName = deptName;
	}


	public String getDeptName() {
		return deptName;
	}


	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}




	

}
