package cg.camp.employeemanagementapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeemoduleapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeemoduleapiApplication.class, args);
	}

}
