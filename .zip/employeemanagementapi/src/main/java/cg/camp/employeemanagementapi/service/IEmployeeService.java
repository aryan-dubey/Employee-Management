package cg.camp.employeemanagementapi.service;

import cg.camp.employeemanagementapi.domain.Employee;

public interface IEmployeeService {
	
	public Employee addEmployee(Employee emp);
	//public void deleteEmployee(long id);
	
}
